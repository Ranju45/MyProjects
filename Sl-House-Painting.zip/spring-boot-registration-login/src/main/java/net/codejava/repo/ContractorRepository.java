package net.codejava.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import net.codejava.entity.Contractor;

public interface ContractorRepository extends JpaRepository<Contractor, Long> {}