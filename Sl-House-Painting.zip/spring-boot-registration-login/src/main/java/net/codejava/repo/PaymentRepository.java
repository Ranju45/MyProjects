package net.codejava.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import net.codejava.entity.Payment;

public interface PaymentRepository extends JpaRepository<Payment, Long> {}