package net.codejava.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import net.codejava.entity.Quotation;
public interface QuotationRepository extends JpaRepository<Quotation, Long> {}