package net.codejava.repo;





import org.springframework.data.jpa.repository.JpaRepository;

import net.codejava.entity.Attendance;

public interface AttendanceRepository extends JpaRepository<Attendance, Long> {
	
}