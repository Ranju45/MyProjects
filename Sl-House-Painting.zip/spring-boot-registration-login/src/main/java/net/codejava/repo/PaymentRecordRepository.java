package net.codejava.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import net.codejava.entity.PaymentRecord;
public interface PaymentRecordRepository extends JpaRepository<PaymentRecord, Long> {}
