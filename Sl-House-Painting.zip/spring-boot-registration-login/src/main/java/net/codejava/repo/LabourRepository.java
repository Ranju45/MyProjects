package net.codejava.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import net.codejava.entity.Labour;

public interface LabourRepository extends JpaRepository<Labour, Long> {
}
