package net.codejava.repo;






import org.springframework.data.jpa.repository.JpaRepository;

import net.codejava.entity.BuildingOwner;

public interface BuildingOwnerRepository extends JpaRepository<BuildingOwner, Long> {}