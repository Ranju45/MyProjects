package net.codejava.entity;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
public class Attendance {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long attendanceId;

    private LocalDate date;
    
    private Boolean present;

    @ManyToOne
    @JoinColumn(name = "labour_id")
    private Labour labour;
    
    

    // Getters and Setters

    public Attendance(Long attendanceId, LocalDate date, Boolean present, Labour labour) {
		super();
		this.attendanceId = attendanceId;
		this.date = date;
		this.present = present;
		this.labour = labour;
	}

	public Attendance() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getAttendanceId() {
        return attendanceId;
    }

    public void setAttendanceId(Long attendanceId) {
        this.attendanceId = attendanceId;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public Boolean getPresent() {
        return present;
    }

    public void setPresent(Boolean present) {
        this.present = present;
    }

    public Labour getLabour() {
        return labour;
    }

    public void setLabour(Labour labour) {
        this.labour = labour;
    }
}
