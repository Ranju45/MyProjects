package net.codejava.entity;

import javax.persistence.*;
import java.util.List;

@Entity
public class Labour {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long labourId;

    private String name;
    private Double perDaySalary;
    private String phoneNumber;
    private String email;
    private Double previousSalary;
    private Double travelAccommodation;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "contractor_id")
    private Contractor contractor;

    @OneToMany(mappedBy = "labour", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Attendance> attendances;

    @OneToMany(mappedBy = "labour", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<PaymentRecord> payments;

    // Constructors
    public Labour() {
    }

    public Labour(Long labourId, String name, Double perDaySalary, String phoneNumber, String email,
                  Double previousSalary, Double travelAccommodation, Contractor contractor,
                  List<Attendance> attendances, List<PaymentRecord> payments) {
        this.labourId = labourId;
        this.name = name;
        this.perDaySalary = perDaySalary;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.previousSalary = previousSalary;
        this.travelAccommodation = travelAccommodation;
        this.contractor = contractor;
        this.attendances = attendances;
        this.payments = payments;
    }

    // Getters and Setters
    public Long getLabourId() {
        return labourId;
    }

    public void setLabourId(Long labourId) {
        this.labourId = labourId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getPerDaySalary() {
        return perDaySalary;
    }

    public void setPerDaySalary(Double perDaySalary) {
        this.perDaySalary = perDaySalary;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Double getPreviousSalary() {
        return previousSalary;
    }

    public void setPreviousSalary(Double previousSalary) {
        this.previousSalary = previousSalary;
    }

    public Double getTravelAccommodation() {
        return travelAccommodation;
    }

    public void setTravelAccommodation(Double travelAccommodation) {
        this.travelAccommodation = travelAccommodation;
    }

    public Contractor getContractor() {
        return contractor;
    }

    public void setContractor(Contractor contractor) {
        this.contractor = contractor;
    }

    public List<Attendance> getAttendances() {
        return attendances;
    }

    public void setAttendances(List<Attendance> attendances) {
        this.attendances = attendances;
    }

    public List<PaymentRecord> getPayments() {
        return payments;
    }

    public void setPayments(List<PaymentRecord> payments) {
        this.payments = payments;
    }
}
