package net.codejava.entity;


import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
public class Quotation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long quotationId;

    private Double materialAndLabourCharge;
    private Double labourChargeOnly;
    private Boolean isAccepted;

    @ManyToOne
    @JoinColumn(name = "owner_id")
    private BuildingOwner owner;

//    @ManyToOne
//    @JoinColumn(name = "contractor_id")
//    private Contractor contractor;
//    
    
    @ManyToOne
    @JoinColumn(name = "contractor_id")
    @JsonBackReference
    private Contractor contractor;

    

	public Quotation(Long quotationId, Double materialAndLabourCharge, Double labourChargeOnly, Boolean isAccepted,
			BuildingOwner owner, Contractor contractor) {
		super();
		this.quotationId = quotationId;
		this.materialAndLabourCharge = materialAndLabourCharge;
		this.labourChargeOnly = labourChargeOnly;
		this.isAccepted = isAccepted;
		this.owner = owner;
		this.contractor = contractor;
	}

	public Quotation() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getQuotationId() {
		return quotationId;
	}

	public void setQuotationId(Long quotationId) {
		this.quotationId = quotationId;
	}

	public Double getMaterialAndLabourCharge() {
		return materialAndLabourCharge;
	}

	public void setMaterialAndLabourCharge(Double materialAndLabourCharge) {
		this.materialAndLabourCharge = materialAndLabourCharge;
	}

	public Double getLabourChargeOnly() {
		return labourChargeOnly;
	}

	public void setLabourChargeOnly(Double labourChargeOnly) {
		this.labourChargeOnly = labourChargeOnly;
	}

	public Boolean getIsAccepted() {
		return isAccepted;
	}

	public void setIsAccepted(Boolean isAccepted) {
		this.isAccepted = isAccepted;
	}

	public BuildingOwner getOwner() {
		return owner;
	}

	public void setOwner(BuildingOwner owner) {
		this.owner = owner;
	}

	public Contractor getContractor() {
		return contractor;
	}

	public void setContractor(Contractor contractor) {
		this.contractor = contractor;
	}

    // Getters and Setters
    
}
