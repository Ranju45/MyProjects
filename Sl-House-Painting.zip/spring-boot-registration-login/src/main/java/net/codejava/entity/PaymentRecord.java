package net.codejava.entity;



import javax.persistence.*;

@Entity
public class PaymentRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long paymentId;

    private String month;
    private Double amount;

    @ManyToOne
    @JoinColumn(name = "labour_id")
    private Labour labour;
    
    

	public PaymentRecord(Long paymentId, String month, Double amount, Labour labour) {
		super();
		this.paymentId = paymentId;
		this.month = month;
		this.amount = amount;
		this.labour = labour;
	}

	public PaymentRecord() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(Long paymentId) {
		this.paymentId = paymentId;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Labour getLabour() {
		return labour;
	}

	public void setLabour(Labour labour) {
		this.labour = labour;
	}

    // Getters and 

}
