package net.codejava.entity;


import javax.persistence.*;

@Entity
public class Feedback {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long feedbackId;

    @ManyToOne
    @JoinColumn(name = "owner_id")
    private BuildingOwner owner;

    @ManyToOne
    @JoinColumn(name = "contractor_id")
    private Contractor contractor;

    private String feedbackText;
    private Integer rating;
	public Long getFeedbackId() {
		return feedbackId;
	}
	
	
	public Feedback(Long feedbackId, BuildingOwner owner, Contractor contractor, String feedbackText, Integer rating) {
		super();
		this.feedbackId = feedbackId;
		this.owner = owner;
		this.contractor = contractor;
		this.feedbackText = feedbackText;
		this.rating = rating;
	}


	public Feedback() {
		super();
		// TODO Auto-generated constructor stub
	}


	public void setFeedbackId(Long feedbackId) {
		this.feedbackId = feedbackId;
	}
	public BuildingOwner getOwner() {
		return owner;
	}
	public void setOwner(BuildingOwner owner) {
		this.owner = owner;
	}
	public Contractor getContractor() {
		return contractor;
	}
	public void setContractor(Contractor contractor) {
		this.contractor = contractor;
	}
	public String getFeedbackText() {
		return feedbackText;
	}
	public void setFeedbackText(String feedbackText) {
		this.feedbackText = feedbackText;
	}
	public Integer getRating() {
		return rating;
	}
	public void setRating(Integer rating) {
		this.rating = rating;
	}

    // Getters and Setters
    
}
