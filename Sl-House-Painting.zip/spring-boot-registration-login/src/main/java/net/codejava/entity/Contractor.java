package net.codejava.entity;



import javax.persistence.*;
import java.util.List;

@Entity
public class Contractor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long contractorId;

    private String name;
    private String phoneNumber;
    private String email;

    @OneToMany(mappedBy = "contractor", cascade = CascadeType.ALL)
    private List<Quotation> quotations;

    @OneToMany(mappedBy = "contractor", cascade = CascadeType.ALL)
    private List<Labour> labours;

    
    
	public Contractor(Long contractorId, String name, String phoneNumber, String email, List<Quotation> quotations,
			List<Labour> labours) {
		super();
		this.contractorId = contractorId;
		this.name = name;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.quotations = quotations;
		this.labours = labours;
	}

	public Contractor() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getContractorId() {
		return contractorId;
	}

	public void setContractorId(Long contractorId) {
		this.contractorId = contractorId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<Quotation> getQuotations() {
		return quotations;
	}

	public void setQuotations(List<Quotation> quotations) {
		this.quotations = quotations;
	}

	public List<Labour> getLabours() {
		return labours;
	}

	public void setLabours(List<Labour> labours) {
		this.labours = labours;
	}

    // Getters and Setters
    
}
