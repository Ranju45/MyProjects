package net.codejava.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.codejava.entity.Contractor;
import net.codejava.repo.ContractorRepository;

import java.util.List;
import java.util.Optional;

@Service
public class ContractorService {

    @Autowired
    private ContractorRepository contractorRepository;

    public List<Contractor> getAllContractors() {
        return contractorRepository.findAll();
    }

    public Optional<Contractor> getContractorById(Long contractorId) {
        return contractorRepository.findById(contractorId);
    }

    public Contractor createContractor(Contractor contractor) {
        return contractorRepository.save(contractor);
    }

    public Contractor updateContractor(Long contractorId, Contractor contractorDetails) {
        Contractor contractor = contractorRepository.findById(contractorId).orElseThrow(() -> new RuntimeException("Contractor not found"));
        contractor.setName(contractorDetails.getName());
        contractor.setPhoneNumber(contractorDetails.getPhoneNumber());
        contractor.setEmail(contractorDetails.getEmail());
        return contractorRepository.save(contractor);
    }

    public void deleteContractor(Long contractorId) {
        contractorRepository.deleteById(contractorId);
    }
}
