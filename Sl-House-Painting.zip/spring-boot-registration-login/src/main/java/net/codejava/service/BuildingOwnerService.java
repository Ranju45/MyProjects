package net.codejava.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.codejava.entity.BuildingOwner;
import net.codejava.repo.BuildingOwnerRepository;

import java.util.List;
import java.util.Optional;

@Service
public class BuildingOwnerService {

    @Autowired
    private BuildingOwnerRepository buildingOwnerRepository;

    public List<BuildingOwner> getAllOwners() {
        return buildingOwnerRepository.findAll();
    }

    public Optional<BuildingOwner> getOwnerById(Long ownerId) {
        return buildingOwnerRepository.findById(ownerId);
    }

    public BuildingOwner createOwner(BuildingOwner owner) {
        return buildingOwnerRepository.save(owner);
    }

    public BuildingOwner updateOwner(Long ownerId, BuildingOwner ownerDetails) {
        BuildingOwner owner = buildingOwnerRepository.findById(ownerId).orElseThrow(() -> new RuntimeException("Owner not found"));
        owner.setName(ownerDetails.getName());
        owner.setAddress(ownerDetails.getAddress());
        owner.setPhoneNumber(ownerDetails.getPhoneNumber());
        owner.setEmail(ownerDetails.getEmail());
        return buildingOwnerRepository.save(owner);
    }

    public void deleteOwner(Long ownerId) {
        buildingOwnerRepository.deleteById(ownerId);
    }
}
