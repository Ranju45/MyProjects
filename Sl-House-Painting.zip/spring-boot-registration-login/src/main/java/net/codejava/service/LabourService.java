package net.codejava.service;

import net.codejava.entity.Labour;
import net.codejava.repo.LabourRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LabourService {

    @Autowired
    private LabourRepository labourRepository;

    public List<Labour> getAllLabours() {
        return labourRepository.findAll();
    }

    public Optional<Labour> getLabourById(Long id) {
        return labourRepository.findById(id);
    }

    public Labour saveLabour(Labour labour) {
        return labourRepository.save(labour);
    }

    public Labour updateLabour(Long id, Labour labourDetails) {
        return labourRepository.findById(id)
                .map(labour -> {
                    labour.setName(labourDetails.getName());
                    labour.setPerDaySalary(labourDetails.getPerDaySalary());
                    labour.setPhoneNumber(labourDetails.getPhoneNumber());
                    labour.setEmail(labourDetails.getEmail());
                    labour.setPreviousSalary(labourDetails.getPreviousSalary());
                    labour.setTravelAccommodation(labourDetails.getTravelAccommodation());
                    labour.setContractor(labourDetails.getContractor());
                    labour.setAttendances(labourDetails.getAttendances());
                    labour.setPayments(labourDetails.getPayments());
                    return labourRepository.save(labour);
                })
                .orElseGet(() -> {
                    labourDetails.setLabourId(id);
                    return labourRepository.save(labourDetails);
                });
    }

    public void deleteLabour(Long id) {
        labourRepository.deleteById(id);
    }
}
