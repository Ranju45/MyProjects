package net.codejava.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.codejava.entity.PaymentRecord;
import net.codejava.repo.PaymentRecordRepository;

import java.util.List;
import java.util.Optional;

@Service
public class PaymentRecordService {

    @Autowired
    private PaymentRecordRepository paymentRecordRepository;

    public List<PaymentRecord> getAllPaymentRecords() {
        return paymentRecordRepository.findAll();
    }

    public Optional<PaymentRecord> getPaymentRecordById(Long id) {
        return paymentRecordRepository.findById(id);
    }

    public PaymentRecord createPaymentRecord(PaymentRecord paymentRecord) {
        return paymentRecordRepository.save(paymentRecord);
    }

    public PaymentRecord updatePaymentRecord(Long id, PaymentRecord paymentRecordDetails) {
        return paymentRecordRepository.findById(id)
                .map(paymentRecord -> {
                    paymentRecord.setMonth(paymentRecordDetails.getMonth());
                    paymentRecord.setAmount(paymentRecordDetails.getAmount());
                    paymentRecord.setLabour(paymentRecordDetails.getLabour());
                    return paymentRecordRepository.save(paymentRecord);
                })
                .orElseThrow(() -> new RuntimeException("PaymentRecord not found with id " + id));
    }

    public void deletePaymentRecord(Long id) {
        paymentRecordRepository.deleteById(id);
    }
}
