package net.codejava.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.codejava.entity.Quotation;
import net.codejava.repo.QuotationRepository;

import java.util.List;
import java.util.Optional;

@Service
public class QuotationService {

    @Autowired
    private QuotationRepository quotationRepository;

    public List<Quotation> getAllQuotations() {
        return quotationRepository.findAll();
    }

    public Optional<Quotation> getQuotationById(Long quotationId) {
        return quotationRepository.findById(quotationId);
    }

    public Quotation createQuotation(Quotation quotation) {
        return quotationRepository.save(quotation);
    }

    public Quotation updateQuotation(Long quotationId, Quotation quotationDetails) {
        Quotation quotation = quotationRepository.findById(quotationId).orElseThrow(() -> new RuntimeException("Quotation not found"));
        quotation.setMaterialAndLabourCharge(quotationDetails.getMaterialAndLabourCharge());
        quotation.setLabourChargeOnly(quotationDetails.getLabourChargeOnly());
        quotation.setIsAccepted(quotationDetails.getIsAccepted());
        return quotationRepository.save(quotation);
    }

    public void deleteQuotation(Long quotationId) {
        quotationRepository.deleteById(quotationId);
    }
}
