package net.codejava.controller;

import net.codejava.entity.Labour;
import net.codejava.service.LabourService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/labours")
public class LabourController {

    @Autowired
    private LabourService labourService;

    @GetMapping
    public List<Labour> getAllLabours() {
        return labourService.getAllLabours();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Labour> getLabourById(@PathVariable Long id) {
        Optional<Labour> labour = labourService.getLabourById(id);
        return labour.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public Labour createLabour(@RequestBody Labour labour) {
        return labourService.saveLabour(labour);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Labour> updateLabour(@PathVariable Long id, @RequestBody Labour labourDetails) {
        Labour updatedLabour = labourService.updateLabour(id, labourDetails);
        return ResponseEntity.ok(updatedLabour);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLabour(@PathVariable Long id) {
        labourService.deleteLabour(id);
        return ResponseEntity.noContent().build();
    }
}
