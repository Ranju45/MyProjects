package net.codejava.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import net.codejava.entity.PaymentRecord;
import net.codejava.service.PaymentRecordService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/paymentRecords")
public class PaymentRecordController {

    @Autowired
    private PaymentRecordService paymentRecordService;

    @GetMapping
    public List<PaymentRecord> getAllPaymentRecords() {
        return paymentRecordService.getAllPaymentRecords();
    }

    @GetMapping("/{id}")
    public ResponseEntity<PaymentRecord> getPaymentRecordById(@PathVariable Long id) {
        Optional<PaymentRecord> paymentRecord = paymentRecordService.getPaymentRecordById(id);
        return paymentRecord.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public PaymentRecord createPaymentRecord(@RequestBody PaymentRecord paymentRecord) {
        return paymentRecordService.createPaymentRecord(paymentRecord);
    }

    @PutMapping("/{id}")
    public ResponseEntity<PaymentRecord> updatePaymentRecord(@PathVariable Long id, @RequestBody PaymentRecord paymentRecordDetails) {
        try {
            PaymentRecord updatedPaymentRecord = paymentRecordService.updatePaymentRecord(id, paymentRecordDetails);
            return ResponseEntity.ok(updatedPaymentRecord);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePaymentRecord(@PathVariable Long id) {
        paymentRecordService.deletePaymentRecord(id);
        return ResponseEntity.noContent().build();
    }
}
