package net.codejava.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import net.codejava.entity.BuildingOwner;
import net.codejava.service.BuildingOwnerService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/owners")
public class BuildingOwnerController {

    @Autowired
    private BuildingOwnerService buildingOwnerService;

    @GetMapping
    public List<BuildingOwner> getAllOwners() {
        return buildingOwnerService.getAllOwners();
    }

    @GetMapping("/{id}")
    public ResponseEntity<BuildingOwner> getOwnerById(@PathVariable Long id) {
        Optional<BuildingOwner> owner = buildingOwnerService.getOwnerById(id);
        return owner.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public BuildingOwner createOwner(@RequestBody BuildingOwner owner) {
        return buildingOwnerService.createOwner(owner);
    }

    @PutMapping("/{id}")
    public ResponseEntity<BuildingOwner> updateOwner(@PathVariable Long id, @RequestBody BuildingOwner ownerDetails) {
        BuildingOwner updatedOwner = buildingOwnerService.updateOwner(id, ownerDetails);
        return ResponseEntity.ok(updatedOwner);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteOwner(@PathVariable Long id) {
        buildingOwnerService.deleteOwner(id);
        return ResponseEntity.noContent().build();
    }
}
